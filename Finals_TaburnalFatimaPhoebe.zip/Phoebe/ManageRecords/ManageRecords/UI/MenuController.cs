using ManageRecords.Logging;
using ManageRecords.Models;
using ManageRecords.Reports;
using ManageRecords.Services;
using ManageRecords.Validation;

namespace ManageRecords.UI;

public sealed class MenuController
{
    private readonly FileRepository _repository;
    private readonly AuditLogger _audit;
    private readonly ReportGenerator _reports;

    public MenuController(FileRepository repository, AuditLogger audit, ReportGenerator reports)
    {
        _repository = repository;
        _audit = audit;
        _reports = reports;
    }

    public void Run()
    {
        Console.WriteLine("==============================================");
        Console.WriteLine("   Library Loan Management System");
        Console.WriteLine("==============================================");
        Console.WriteLine();

        var running = true;
        while (running)
        {
            PrintMenu();
            var choice = ReadLine("Enter choice: ");

            try
            {
                running = choice switch
                {
                    "1" => RunAdd() || ContinueLoop(),
                    "2" => RunView() || ContinueLoop(),
                    "3" => RunUpdate() || ContinueLoop(),
                    "4" => RunSoftDelete() || ContinueLoop(),
                    "5" => RunHardDelete() || ContinueLoop(),
                    "6" => RunReport() || ContinueLoop(),
                    "0" => Exit(),
                    _ => InvalidChoice()
                };
            }
            catch (IOException ex)
            {
                Console.WriteLine($"Storage error: {ex.Message}");
                _audit.LogError($"IO exception in menu: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
                _audit.LogError($"Unhandled exception: {ex.Message}");
            }

            if (running)
            {
                Console.WriteLine();
                Pause();
            }
        }
    }

    private static bool ContinueLoop() => true;

    private static void PrintMenu()
    {
        Console.WriteLine();
        Console.WriteLine("--- MAIN MENU ---");
        Console.WriteLine("  1. Add loan record");
        Console.WriteLine("  2. View active loans (with search)");
        Console.WriteLine("  3. Update loan record");
        Console.WriteLine("  4. Soft delete (mark inactive)");
        Console.WriteLine("  5. Hard delete (remove from file)");
        Console.WriteLine("  6. Generate library loans report");
        Console.WriteLine("  0. Exit");
        Console.WriteLine();
    }

    private bool RunAdd()
    {
        Console.WriteLine();
        Console.WriteLine("--- ADD LOAN RECORD ---");

        var borrower = ReadLine("Borrower name: ");
        var title = ReadLine("Book title: ");
        var isbn = ReadLine("ISBN (10 or 13 digits): ");
        var loanDate = ReadDate("Loan date (yyyy-MM-dd): ");
        if (loanDate is null)
            return true;

        var dueDate = ReadDate("Due date (yyyy-MM-dd): ");
        if (dueDate is null)
            return true;

        var validation = RecordValidator.ValidateForAdd(
            borrower, title, isbn, loanDate.Value, dueDate.Value);

        if (!validation.IsValid)
        {
            foreach (var err in validation.Errors)
                Console.WriteLine($"  ! {err}");
            _audit.LogError($"Add validation failed: {string.Join("; ", validation.Errors)}");
            return true;
        }

        var now = DateTime.Now;
        var record = new LibraryLoanRecord
        {
            RecordId = _repository.GenerateNextId(),
            BorrowerName = borrower.Trim(),
            BookTitle = title.Trim(),
            Isbn = new string(isbn.Where(char.IsDigit).ToArray()),
            LoanDate = loanDate.Value.Date,
            DueDate = dueDate.Value.Date,
            CreatedAt = now,
            UpdatedAt = now,
            IsActive = true
        };

        if (_repository.Add(record))
            Console.WriteLine($"Loan saved. Record ID: {record.RecordId}");
        else
        {
            Console.WriteLine("Failed to save record (duplicate ID).");
            _audit.LogError($"Add failed for {record.RecordId}");
        }

        return true;
    }

    private bool RunView()
    {
        Console.WriteLine();
        Console.WriteLine("--- VIEW ACTIVE LOANS ---");

        IReadOnlyList<LibraryLoanRecord> records;
        try
        {
            records = _repository.LoadAll(includeInactive: false);
        }
        catch (IOException)
        {
            Console.WriteLine("Could not load records.");
            return true;
        }

        Console.WriteLine("Filter by: 1=Borrower name  2=Book title  3=ISBN  4=Show all");
        var filterChoice = ReadLine("Filter option: ");

        var filtered = filterChoice switch
        {
            "1" => FilterByBorrower(records),
            "2" => FilterByTitle(records),
            "3" => FilterByIsbn(records),
            "4" or "" => records,
            _ => null
        };

        if (filtered is null)
        {
            Console.WriteLine("Invalid filter option.");
            _audit.LogError("View: invalid filter option.");
            return true;
        }

        _audit.Log(AuditAction.Read, $"View displayed {filtered.Count} record(s), filter={filterChoice}");

        if (filtered.Count == 0)
        {
            Console.WriteLine("No matching active loans found.");
            return true;
        }

        Console.WriteLine();
        foreach (var r in filtered.OrderBy(x => x.DueDate))
            PrintRecord(r);

        return true;
    }

    private IReadOnlyList<LibraryLoanRecord> FilterByBorrower(IReadOnlyList<LibraryLoanRecord> records)
    {
        var term = ReadLine("Borrower name contains: ");
        return records
            .Where(r => r.BorrowerName.Contains(term, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    private IReadOnlyList<LibraryLoanRecord> FilterByTitle(IReadOnlyList<LibraryLoanRecord> records)
    {
        var term = ReadLine("Book title contains: ");
        return records
            .Where(r => r.BookTitle.Contains(term, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    private IReadOnlyList<LibraryLoanRecord> FilterByIsbn(IReadOnlyList<LibraryLoanRecord> records)
    {
        var term = ReadLine("ISBN contains: ");
        var digits = new string(term.Where(char.IsDigit).ToArray());
        return records
            .Where(r => r.Isbn.Contains(digits, StringComparison.Ordinal))
            .ToList();
    }

    private bool RunUpdate()
    {
        Console.WriteLine();
        Console.WriteLine("--- UPDATE LOAN RECORD ---");

        var id = ReadLine("Record ID: ");
        LibraryLoanRecord? record;
        try
        {
            record = _repository.GetById(id);
        }
        catch (IOException)
        {
            Console.WriteLine("Could not load records.");
            return true;
        }

        if (record is null)
        {
            Console.WriteLine("Record not found.");
            _audit.LogError($"Update: record not found {id}");
            return true;
        }

        if (!record.IsActive)
        {
            Console.WriteLine("Record is inactive. Reactivate via update is not supported; add a new loan instead.");
            return true;
        }

        PrintRecord(record);
        Console.WriteLine();
        Console.WriteLine("Press Enter to keep current value.");

        record.BorrowerName = ReadLineOrDefault("Borrower name", record.BorrowerName);
        record.BookTitle = ReadLineOrDefault("Book title", record.BookTitle);
        record.Isbn = ReadLineOrDefault("ISBN", record.Isbn);
        record.LoanDate = ReadDateOrDefault("Loan date (yyyy-MM-dd)", record.LoanDate);
        record.DueDate = ReadDateOrDefault("Due date (yyyy-MM-dd)", record.DueDate);

        record.Isbn = new string(record.Isbn.Where(char.IsDigit).ToArray());

        var validation = RecordValidator.ValidateForUpdate(record);
        if (!validation.IsValid)
        {
            foreach (var err in validation.Errors)
                Console.WriteLine($"  ! {err}");
            _audit.LogError($"Update validation failed for {id}");
            return true;
        }

        if (_repository.Update(record))
            Console.WriteLine("Record updated successfully.");
        else
            Console.WriteLine("Update failed.");

        return true;
    }

    private bool RunSoftDelete()
    {
        Console.WriteLine();
        Console.WriteLine("--- SOFT DELETE ---");
        var id = ReadLine("Record ID: ");

        try
        {
            if (_repository.SoftDelete(id))
                Console.WriteLine("Record marked inactive.");
            else
            {
                Console.WriteLine("Record not found or already inactive.");
                _audit.LogError($"Soft delete failed for {id}");
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Could not update storage: {ex.Message}");
        }

        return true;
    }

    private bool RunHardDelete()
    {
        Console.WriteLine();
        Console.WriteLine("--- HARD DELETE (permanent) ---");
        var id = ReadLine("Record ID: ");
        var confirm = ReadLine("Type DELETE to confirm: ");

        if (!confirm.Equals("DELETE", StringComparison.Ordinal))
        {
            Console.WriteLine("Hard delete cancelled.");
            return true;
        }

        try
        {
            if (_repository.HardDelete(id))
                Console.WriteLine("Record permanently removed.");
            else
            {
                Console.WriteLine("Record not found.");
                _audit.LogError($"Hard delete failed for {id}");
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Could not update storage: {ex.Message}");
        }

        return true;
    }

    private bool RunReport()
    {
        Console.WriteLine();
        Console.WriteLine("--- GENERATE REPORT ---");

        IReadOnlyList<LibraryLoanRecord> active;
        try
        {
            active = _repository.LoadAll(includeInactive: false);
        }
        catch (IOException)
        {
            Console.WriteLine("Could not load records for report.");
            return true;
        }

        var content = _reports.Generate(active);
        Console.WriteLine(content);

        try
        {
            var path = _reports.SaveReportToFile(content);
            Console.WriteLine($"Report also saved to: {path}");
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Report displayed but could not save file: {ex.Message}");
        }

        return true;
    }

    private bool Exit()
    {
        _audit.Log(AuditAction.Read, "Application exit.");
        Console.WriteLine("Goodbye.");
        return false;
    }

    private bool InvalidChoice()
    {
        Console.WriteLine("Invalid menu choice. Please try again.");
        _audit.LogError($"Invalid menu choice.");
        return true;
    }

    private static void PrintRecord(LibraryLoanRecord r)
    {
        Console.WriteLine($"  ID: {r.RecordId}  |  Active: {(r.IsActive ? "Yes" : "No")}");
        Console.WriteLine($"  Borrower: {r.BorrowerName}");
        Console.WriteLine($"  Book: {r.BookTitle}");
        Console.WriteLine($"  ISBN: {r.Isbn}");
        Console.WriteLine($"  Loan: {r.LoanDate:yyyy-MM-dd}  Due: {r.DueDate:yyyy-MM-dd}");
        Console.WriteLine($"  Created: {r.CreatedAt:yyyy-MM-dd HH:mm}  Updated: {r.UpdatedAt:yyyy-MM-dd HH:mm}");
        Console.WriteLine($"  Checksum: {r.Checksum[..Math.Min(16, r.Checksum.Length)]}...");
        Console.WriteLine("  ----------------------------------------");
    }

    private static string ReadLine(string prompt)
    {
        Console.Write(prompt);
        return Console.ReadLine()?.Trim() ?? string.Empty;
    }

    private static string ReadLineOrDefault(string prompt, string current)
    {
        Console.Write($"{prompt} [{current}]: ");
        var input = Console.ReadLine()?.Trim();
        return string.IsNullOrEmpty(input) ? current : input;
    }

    private static DateTime? ReadDate(string prompt)
    {
        var input = ReadLine(prompt);
        if (!DateTime.TryParse(input, out var date))
        {
            Console.WriteLine("Invalid date format.");
            return null;
        }

        return date.Date;
    }

    private static DateTime ReadDateOrDefault(string prompt, DateTime current)
    {
        Console.Write($"{prompt} [{current:yyyy-MM-dd}]: ");
        var input = Console.ReadLine()?.Trim();
        if (string.IsNullOrEmpty(input))
            return current.Date;

        return DateTime.TryParse(input, out var date) ? date.Date : current.Date;
    }

    private static void Pause()
    {
        Console.WriteLine("Press any key to continue...");
        Console.ReadKey(true);
    }
}
