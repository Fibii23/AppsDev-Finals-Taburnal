using ManageRecords.Logging;
using ManageRecords.Models;
using ManageRecords.Storage;

namespace ManageRecords.Reports;

/// <summary>
/// Personalized report rules for Library Loans:
/// 1. Summary of all active loans
/// 2. Overdue loans (due date passed, still active)
/// 3. Loans due within the next 7 days
/// 4. Top borrowers by active loan count
/// </summary>
public sealed class ReportGenerator
{
    private readonly AuditLogger _audit;

    public ReportGenerator(AuditLogger audit)
    {
        _audit = audit;
    }

    public string Generate(IReadOnlyList<LibraryLoanRecord> activeRecords)
    {
        var today = DateTime.Today;
        var dueSoonEnd = today.AddDays(7);

        var overdue = activeRecords
            .Where(r => r.DueDate.Date < today)
            .OrderBy(r => r.DueDate)
            .ToList();

        var dueSoon = activeRecords
            .Where(r => r.DueDate.Date >= today && r.DueDate.Date <= dueSoonEnd)
            .OrderBy(r => r.DueDate)
            .ToList();

        var topBorrowers = activeRecords
            .GroupBy(r => r.BorrowerName.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Name = g.Key, Count = g.Count() })
            .OrderByDescending(x => x.Count)
            .ThenBy(x => x.Name)
            .Take(10)
            .ToList();

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("========================================");
        sb.AppendLine("   LIBRARY LOANS REPORT");
        sb.AppendLine($"   Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("========================================");
        sb.AppendLine();
        sb.AppendLine("--- SUMMARY ---");
        sb.AppendLine($"Total active loans: {activeRecords.Count}");
        sb.AppendLine($"Overdue loans:      {overdue.Count}");
        sb.AppendLine($"Due within 7 days:  {dueSoon.Count}");
        sb.AppendLine();

        AppendSection(sb, "OVERDUE LOANS", overdue, today);
        AppendSection(sb, "DUE WITHIN 7 DAYS", dueSoon, today);

        sb.AppendLine("--- TOP BORROWERS (by active loan count) ---");
        if (topBorrowers.Count == 0)
            sb.AppendLine("  (none)");
        else
        {
            foreach (var b in topBorrowers)
                sb.AppendLine($"  {b.Name}: {b.Count} loan(s)");
        }

        sb.AppendLine();
        sb.AppendLine("========================================");

        return sb.ToString();
    }

    public string SaveReportToFile(string reportContent)
    {
        var fileName = $"library_loans_report_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
        var path = Path.Combine(StorageInitializer.ReportsPath, fileName);

        try
        {
            File.WriteAllText(path, reportContent);
            _audit.Log(AuditAction.Read, $"Report saved to {path}");
            return path;
        }
        catch (IOException ex)
        {
            _audit.LogError($"Failed to save report: {ex.Message}");
            throw;
        }
    }

    private static void AppendSection(
        System.Text.StringBuilder sb,
        string title,
        List<LibraryLoanRecord> records,
        DateTime today)
    {
        sb.AppendLine($"--- {title} ---");
        if (records.Count == 0)
        {
            sb.AppendLine("  (none)");
            sb.AppendLine();
            return;
        }

        foreach (var r in records)
        {
            var days = (today - r.DueDate.Date).Days;
            var status = days > 0 ? $"{days} day(s) overdue" : $"due in {(r.DueDate.Date - today).Days} day(s)";
            sb.AppendLine($"  [{r.RecordId}] {r.BorrowerName}");
            sb.AppendLine($"      Book: {r.BookTitle} (ISBN: {r.Isbn})");
            sb.AppendLine($"      Loan: {r.LoanDate:yyyy-MM-dd}  Due: {r.DueDate:yyyy-MM-dd}  ({status})");
        }

        sb.AppendLine();
    }
}
