﻿using ManageRecords.Logging;
using ManageRecords.Reports;
using ManageRecords.Services;
using ManageRecords.Storage;
using ManageRecords.UI;

StorageInitializer.Initialize();

var audit = new AuditLogger();
var repository = new FileRepository(audit);
var reports = new ReportGenerator(audit);
var menu = new MenuController(repository, audit, reports);

audit.Log(AuditAction.Read, "Application started. Storage initialized.");

menu.Run();
