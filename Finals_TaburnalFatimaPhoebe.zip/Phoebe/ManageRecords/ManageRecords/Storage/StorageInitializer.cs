namespace ManageRecords.Storage;

public static class StorageInitializer
{
    public const string DataDirectory = "data";
    public const string LogsDirectory = "logs";
    public const string ReportsDirectory = "reports";
    public const string RecordsFileName = "library_loans.dat";
    public const string AuditFileName = "audit.log";
    public const string IdCounterFileName = "id_counter.txt";

    public static string RecordsPath => Path.Combine(DataDirectory, RecordsFileName);
    public static string AuditPath => Path.Combine(LogsDirectory, AuditFileName);
    public static string IdCounterPath => Path.Combine(DataDirectory, IdCounterFileName);
    public static string ReportsPath => ReportsDirectory;

    public static void Initialize()
    {
        Directory.CreateDirectory(DataDirectory);
        Directory.CreateDirectory(LogsDirectory);
        Directory.CreateDirectory(ReportsDirectory);

        if (!File.Exists(RecordsPath))
            File.WriteAllText(RecordsPath, string.Empty);

        if (!File.Exists(AuditPath))
            File.WriteAllText(AuditPath, string.Empty);

        if (!File.Exists(IdCounterPath))
            File.WriteAllText(IdCounterPath, "0");
    }
}
