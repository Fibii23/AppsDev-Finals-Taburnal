using ManageRecords.Models;

namespace ManageRecords.Validation;

public sealed class ValidationResult
{
    public bool IsValid { get; init; }
    public IReadOnlyList<string> Errors { get; init; } = Array.Empty<string>();

    public static ValidationResult Success() => new() { IsValid = true };

    public static ValidationResult Failure(params string[] errors) =>
        new() { IsValid = false, Errors = errors };
}

public static class RecordValidator
{
    private const int MaxNameLength = 100;
    private const int MaxTitleLength = 200;

    public static ValidationResult ValidateForAdd(
        string borrowerName,
        string bookTitle,
        string isbn,
        DateTime loanDate,
        DateTime dueDate)
    {
        var errors = new List<string>();
        ValidateBorrowerName(borrowerName, errors);
        ValidateBookTitle(bookTitle, errors);
        ValidateIsbn(isbn, errors);
        ValidateDates(loanDate, dueDate, errors);
        return errors.Count == 0 ? ValidationResult.Success() : ValidationResult.Failure(errors.ToArray());
    }

    public static ValidationResult ValidateForUpdate(LibraryLoanRecord record)
    {
        var errors = new List<string>();
        if (string.IsNullOrWhiteSpace(record.RecordId))
            errors.Add("Record ID is required.");

        ValidateBorrowerName(record.BorrowerName, errors);
        ValidateBookTitle(record.BookTitle, errors);
        ValidateIsbn(record.Isbn, errors);
        ValidateDates(record.LoanDate, record.DueDate, errors);
        return errors.Count == 0 ? ValidationResult.Success() : ValidationResult.Failure(errors.ToArray());
    }

    public static ValidationResult ValidateIntegrity(LibraryLoanRecord record, bool checksumValid)
    {
        if (!checksumValid)
            return ValidationResult.Failure("Stored checksum does not match record data (possible corruption).");
        return ValidationResult.Success();
    }

    private static void ValidateBorrowerName(string value, List<string> errors)
    {
        if (string.IsNullOrWhiteSpace(value))
            errors.Add("Borrower name is required.");
        else if (value.Trim().Length > MaxNameLength)
            errors.Add($"Borrower name must be at most {MaxNameLength} characters.");
    }

    private static void ValidateBookTitle(string value, List<string> errors)
    {
        if (string.IsNullOrWhiteSpace(value))
            errors.Add("Book title is required.");
        else if (value.Trim().Length > MaxTitleLength)
            errors.Add($"Book title must be at most {MaxTitleLength} characters.");
    }

    private static void ValidateIsbn(string value, List<string> errors)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            errors.Add("ISBN is required.");
            return;
        }

        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.Length is not (10 or 13))
            errors.Add("ISBN must contain 10 or 13 digits (hyphens allowed).");
    }

    private static void ValidateDates(DateTime loanDate, DateTime dueDate, List<string> errors)
    {
        if (loanDate.Date > DateTime.Today)
            errors.Add("Loan date cannot be in the future.");

        if (dueDate.Date < loanDate.Date)
            errors.Add("Due date must be on or after the loan date.");
    }
}
