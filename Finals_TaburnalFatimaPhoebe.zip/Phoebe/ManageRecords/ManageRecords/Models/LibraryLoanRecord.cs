namespace ManageRecords.Models;

/// <summary>Library loan record persisted to file storage.</summary>
public class LibraryLoanRecord
{
    public string RecordId { get; set; } = string.Empty;
    public string BorrowerName { get; set; } = string.Empty;
    public string BookTitle { get; set; } = string.Empty;
    public string Isbn { get; set; } = string.Empty;
    public DateTime LoanDate { get; set; }
    public DateTime DueDate { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;
    public string Checksum { get; set; } = string.Empty;

    public string ToStorageLine() =>
        string.Join('|',
            RecordId,
            Escape(BorrowerName),
            Escape(BookTitle),
            Escape(Isbn),
            LoanDate.ToString("O"),
            DueDate.ToString("O"),
            CreatedAt.ToString("O"),
            UpdatedAt.ToString("O"),
            IsActive ? "1" : "0",
            Checksum);

    public static bool TryParseStorageLine(string line, out LibraryLoanRecord? record, out string error)
    {
        record = null;
        error = string.Empty;

        if (string.IsNullOrWhiteSpace(line))
        {
            error = "Empty line.";
            return false;
        }

        var parts = SplitLine(line);
        if (parts.Count != 10)
        {
            error = $"Expected 10 fields, found {parts.Count}.";
            return false;
        }

        if (!DateTime.TryParse(parts[4], out var loanDate) ||
            !DateTime.TryParse(parts[5], out var dueDate) ||
            !DateTime.TryParse(parts[6], out var createdAt) ||
            !DateTime.TryParse(parts[7], out var updatedAt))
        {
            error = "Invalid date format in stored record.";
            return false;
        }

        record = new LibraryLoanRecord
        {
            RecordId = parts[0],
            BorrowerName = Unescape(parts[1]),
            BookTitle = Unescape(parts[2]),
            Isbn = Unescape(parts[3]),
            LoanDate = loanDate,
            DueDate = dueDate,
            CreatedAt = createdAt,
            UpdatedAt = updatedAt,
            IsActive = parts[8] == "1",
            Checksum = parts[9]
        };
        return true;
    }

    public string CanonicalPayload() =>
        $"{RecordId}|{BorrowerName}|{BookTitle}|{Isbn}|{LoanDate:O}|{DueDate:O}|{CreatedAt:O}|{UpdatedAt:O}|{(IsActive ? 1 : 0)}";

    private static string Escape(string value) => value.Replace("|", "\\|").Replace("\r", "").Replace("\n", " ");

    private static string Unescape(string value) => value.Replace("\\|", "|");

    private static List<string> SplitLine(string line)
    {
        var parts = new List<string>();
        var current = new System.Text.StringBuilder();
        var escaped = false;

        foreach (var ch in line)
        {
            if (escaped)
            {
                current.Append(ch);
                escaped = false;
                continue;
            }

            if (ch == '\\')
            {
                escaped = true;
                continue;
            }

            if (ch == '|')
            {
                parts.Add(current.ToString());
                current.Clear();
                continue;
            }

            current.Append(ch);
        }

        parts.Add(current.ToString());
        return parts;
    }
}
