using ManageRecords.Logging;
using ManageRecords.Models;
using ManageRecords.Storage;
using ManageRecords.Validation;

namespace ManageRecords.Services;

public sealed class FileRepository
{
    private readonly AuditLogger _audit;
    private readonly object _lock = new();

    public FileRepository(AuditLogger audit)
    {
        _audit = audit;
    }

    public IReadOnlyList<LibraryLoanRecord> LoadAll(bool includeInactive = false)
    {
        lock (_lock)
        {
            try
            {
                if (!File.Exists(StorageInitializer.RecordsPath))
                    return Array.Empty<LibraryLoanRecord>();

                var lines = File.ReadAllLines(StorageInitializer.RecordsPath);
                var records = new List<LibraryLoanRecord>();

                for (var i = 0; i < lines.Length; i++)
                {
                    var line = lines[i];
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    if (!LibraryLoanRecord.TryParseStorageLine(line, out var record, out var parseError) || record is null)
                    {
                        _audit.LogError($"Malformed record at line {i + 1}: {parseError}");
                        continue;
                    }

                    if (!ChecksumService.Verify(record))
                    {
                        _audit.LogError($"Checksum mismatch for record {record.RecordId} at line {i + 1}.");
                        continue;
                    }

                    if (!includeInactive && !record.IsActive)
                        continue;

                    records.Add(record);
                }

                _audit.Log(AuditAction.Read, $"Loaded {records.Count} record(s) (includeInactive={includeInactive}).");
                return records;
            }
            catch (IOException ex)
            {
                _audit.LogError($"IO error loading records: {ex.Message}");
                throw;
            }
        }
    }

    public LibraryLoanRecord? GetById(string recordId, bool includeInactive = true)
    {
        return LoadAll(includeInactive: true)
            .FirstOrDefault(r => r.RecordId.Equals(recordId, StringComparison.OrdinalIgnoreCase));
    }

    public string GenerateNextId()
    {
        lock (_lock)
        {
            var counter = 0;
            if (File.Exists(StorageInitializer.IdCounterPath))
            {
                var text = File.ReadAllText(StorageInitializer.IdCounterPath).Trim();
                int.TryParse(text, out counter);
            }

            counter++;
            File.WriteAllText(StorageInitializer.IdCounterPath, counter.ToString());
            return $"LOAN-{counter:D5}";
        }
    }

    public bool Add(LibraryLoanRecord record)
    {
        lock (_lock)
        {
            var all = LoadAllInternal();
            if (all.Any(r => r.RecordId.Equals(record.RecordId, StringComparison.OrdinalIgnoreCase)))
                return false;

            record.Checksum = ChecksumService.Compute(record);
            all.Add(record);
            SaveAllInternal(all);
            _audit.Log(AuditAction.Add, $"RecordId={record.RecordId}, Borrower={record.BorrowerName}, Book={record.BookTitle}");
            return true;
        }
    }

    public bool Update(LibraryLoanRecord updated)
    {
        lock (_lock)
        {
            var all = LoadAllInternal();
            var index = all.FindIndex(r =>
                r.RecordId.Equals(updated.RecordId, StringComparison.OrdinalIgnoreCase));

            if (index < 0)
                return false;

            updated.UpdatedAt = DateTime.Now;
            updated.Checksum = ChecksumService.Compute(updated);
            all[index] = updated;
            SaveAllInternal(all);
            _audit.Log(AuditAction.Update, $"RecordId={updated.RecordId}");
            return true;
        }
    }

    public bool SoftDelete(string recordId)
    {
        lock (_lock)
        {
            var all = LoadAllInternal();
            var record = all.FirstOrDefault(r =>
                r.RecordId.Equals(recordId, StringComparison.OrdinalIgnoreCase));

            if (record is null || !record.IsActive)
                return false;

            record.IsActive = false;
            record.UpdatedAt = DateTime.Now;
            record.Checksum = ChecksumService.Compute(record);
            SaveAllInternal(all);
            _audit.Log(AuditAction.Delete, $"Soft delete RecordId={recordId}");
            return true;
        }
    }

    public bool HardDelete(string recordId)
    {
        lock (_lock)
        {
            var all = LoadAllInternal();
            var removed = all.RemoveAll(r =>
                r.RecordId.Equals(recordId, StringComparison.OrdinalIgnoreCase));

            if (removed == 0)
                return false;

            SaveAllInternal(all);
            _audit.Log(AuditAction.Delete, $"Hard delete RecordId={recordId}");
            return true;
        }
    }

    private List<LibraryLoanRecord> LoadAllInternal()
    {
        if (!File.Exists(StorageInitializer.RecordsPath))
            return new List<LibraryLoanRecord>();

        var result = new List<LibraryLoanRecord>();
        foreach (var line in File.ReadAllLines(StorageInitializer.RecordsPath))
        {
            if (string.IsNullOrWhiteSpace(line))
                continue;

            if (LibraryLoanRecord.TryParseStorageLine(line, out var record, out _) && record is not null)
                result.Add(record);
        }

        return result;
    }

    private static void SaveAllInternal(List<LibraryLoanRecord> records)
    {
        var lines = records.Select(r =>
        {
            r.Checksum = ChecksumService.Compute(r);
            return r.ToStorageLine();
        });
        File.WriteAllLines(StorageInitializer.RecordsPath, lines);
    }
}
