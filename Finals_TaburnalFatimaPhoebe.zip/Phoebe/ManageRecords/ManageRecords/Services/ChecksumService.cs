using System.Security.Cryptography;
using System.Text;
using ManageRecords.Models;

namespace ManageRecords.Services;

public static class ChecksumService
{
    public static string Compute(LibraryLoanRecord record)
    {
        var bytes = Encoding.UTF8.GetBytes(record.CanonicalPayload());
        var hash = SHA256.HashData(bytes);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public static bool Verify(LibraryLoanRecord record) =>
        string.Equals(Compute(record), record.Checksum, StringComparison.OrdinalIgnoreCase);
}
