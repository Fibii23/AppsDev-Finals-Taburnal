using ManageRecords.Storage;

namespace ManageRecords.Logging;

public enum AuditAction
{
    Add,
    Update,
    Delete,
    Read,
    Error
}

public sealed class AuditLogger
{
    private readonly object _lock = new();

    public void Log(AuditAction action, string details)
    {
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}|{action}|{Sanitize(details)}";
        try
        {
            lock (_lock)
            {
                File.AppendAllText(StorageInitializer.AuditPath, line + Environment.NewLine);
            }
        }
        catch
        {
            Console.WriteLine("Warning: Could not write to audit log.");
        }
    }

    public void LogError(string details) => Log(AuditAction.Error, details);

    private static string Sanitize(string value) =>
        value.Replace(Environment.NewLine, " ").Replace('|', '/');
}
